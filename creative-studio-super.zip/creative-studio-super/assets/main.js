
/* ===== Global Config ===== */
const BRAND_EMAIL = 'forsecondarywork1572027@gmail.com';
const FORMSPREE_ID = ''; // Fill with your Formspree ID (e.g., "mbjnpqxy")
const APPS_SCRIPT_URL = ''; // Optional Google Apps Script endpoint

/* ===== Utilities ===== */
function $(sel, root=document){ return root.querySelector(sel); }
function $all(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
function formatINR(n){ return '₹'+Number(n).toLocaleString('en-IN'); }

/* ===== Theme ===== */
const rootEl = document.documentElement;
const iconSun = document.getElementById('iconSun');
const iconMoon = document.getElementById('iconMoon');
function setTheme(t){
  rootEl.setAttribute('data-theme', t);
  localStorage.setItem('theme', t);
  const dark = t==='dark';
  iconSun?.classList.toggle('hidden', dark);
  iconMoon?.classList.toggle('hidden', !dark);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = dark ? '#0b0b12' : '#ffffff';
}
(function initTheme(){
  const saved = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  setTheme(saved || (prefersDark ? 'dark' : 'light'));
})();
document.getElementById('themeToggle')?.addEventListener('click', ()=> setTheme(rootEl.getAttribute('data-theme')==='dark' ? 'light' : 'dark'));

/* ===== Header/Footer injection ===== */
async function injectShell(){
  const header = document.getElementById('app-header');
  const footer = document.getElementById('app-footer');
  try{
    if(header){
      const res = await fetch('/partials/header.html'); header.innerHTML = await res.text();
      // re-bind theme toggle after injection
      document.getElementById('themeToggle')?.addEventListener('click', ()=> setTheme(rootEl.getAttribute('data-theme')==='dark' ? 'light' : 'dark'));
      // Active link
      const path = location.pathname.replace(/\/+$/, '') || '/index.html';
      $all('.nav-link', header).forEach(a => { if(a.getAttribute('href')===path) a.classList.add('active'); });
      // Mobile menu
      const menuBtn = document.getElementById('menuBtn'); const mobileMenu = document.getElementById('mobileMenu');
      menuBtn?.addEventListener('click', ()=>{ mobileMenu.classList.toggle('hidden'); mobileMenu.classList.toggle('open'); }, {passive:true});
    }
    if(footer){
      const res = await fetch('/partials/footer.html'); footer.innerHTML = await res.text();
      document.getElementById('year').textContent = new Date().getFullYear();
    }
  }catch(e){ console.warn('Shell injection failed', e); }
}
injectShell();

/* ===== Scroll to top ===== */
const toTop = document.getElementById('toTop');
if(toTop){
  let ticking = false;
  window.addEventListener('scroll', ()=>{
    if(!ticking){ requestAnimationFrame(()=>{ (window.scrollY>420) ? toTop.classList.add('show') : toTop.classList.remove('show'); ticking=false; }); ticking=true; }
  }, {passive:true});
  toTop.addEventListener('click', ()=> window.scrollTo({top:0, behavior:'smooth'}), {passive:true});
}

/* ===== Pricing toggle (only where present) ===== */
(function pricing(){
  const toggle = document.getElementById('billingToggle');
  const prices = document.querySelectorAll('.price');
  if(!toggle || !prices.length) return;
  function update(){ const yearly = toggle.checked; prices.forEach(p=>{ const val = +p.getAttribute(yearly? 'data-year':'data-month'); p.textContent = formatINR(val); }); }
  toggle.addEventListener('change', update, {passive:true}); update();
})();

/* ===== Contact form (if present) with honeypot ===== */
(function contactForm(){
  const form = document.getElementById('contactForm'); if(!form) return;
  const toast = document.getElementById('formToast');
  const btn = document.getElementById('submitBtn');
  const spinner = document.getElementById('btnSpinner');
  const check = document.getElementById('btnCheck');
  function showToast(msg, ok=true){ toast.className = 'mt-4 text-sm ' + (ok ? 'text-emerald-400' : 'text-red-400'); toast.textContent = msg; toast.classList.remove('hidden'); }
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(form);
    // honeypot field botCheck should be empty
    if(fd.get('botCheck')) return;
    const data = Object.fromEntries(fd.entries());
    if(!data.name || !data.email || !data.message){ showToast('Please fill all fields.', false); return; }
    spinner?.classList?.remove('hidden'); check?.classList?.add('hidden'); if(btn) btn.disabled = true; showToast('Sending…', true);
    if(FORMSPREE_ID){
      try{ const res = await fetch(`https://formspree.io/f/${FORMSPREE_ID}`, { method:'POST', headers:{'Accept':'application/json'}, body: fd });
        if(res.ok){ showToast('Thanks! Your message has been sent.'); form.reset(); check?.classList?.remove('hidden'); }
        else{ const j = await res.json().catch(()=>({})); showToast(j?.errors?.[0]?.message || 'Formspree error. Falling back…', false); }
      }catch{ showToast('Network error with Formspree. Falling back…', false); }
    }
    if(!toast.textContent.includes('Thanks') && APPS_SCRIPT_URL){
      try{ await fetch(APPS_SCRIPT_URL, { method:'POST', mode:'no-cors', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) }); showToast('Thanks! Your message has been recorded.'); form.reset(); check?.classList?.remove('hidden'); }
      catch{ showToast('Couldn’t reach Google Sheets. Falling back…', false); }
    }
    if(!toast.textContent.includes('Thanks')){
      const subject = encodeURIComponent(`New Project Inquiry — ${data.name}`);
      const body = encodeURIComponent(`${data.message}\n\nFrom: ${data.name}\nEmail: ${data.email}`);
      window.location.href = `mailto:${BRAND_EMAIL}?subject=${subject}&body=${body}`;
      showToast('Opening your email app to send the message…');
    }
    spinner?.classList?.add('hidden'); if(btn) btn.disabled = false;
  }, {passive:false});
})();

/* ===== Job application form (if present) ===== */
(function jobForm(){
  const jobForm = document.getElementById('jobForm'); if(!jobForm) return;
  const toast = document.getElementById('formToast');
  const applyBtn = document.getElementById('applyBtn');
  const spinner = document.getElementById('btnSpinner');
  const check = document.getElementById('btnCheck');
  function showToast(msg, ok=true){ toast.className = 'text-sm ' + (ok ? 'text-emerald-400' : 'text-red-400'); toast.textContent = msg; toast.classList.remove('hidden'); }
  jobForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(jobForm);
    if(fd.get('botCheck')) return; // honeypot
    const data = Object.fromEntries(fd.entries());
    if(!data.name || !data.phone || !data.email || !data.skills){ showToast('Please fill all required fields.', false); return; }
    spinner?.classList?.remove('hidden'); check?.classList?.add('hidden'); if(applyBtn) applyBtn.disabled = true; showToast('Sending…', true);
    if(FORMSPREE_ID){
      try{
        const res = await fetch(`https://formspree.io/f/${FORMSPREE_ID}`, { method:'POST', body: fd });
        if(res.ok){ showToast('Thanks! Your application has been sent.'); jobForm.reset(); check?.classList?.remove('hidden'); }
        else{ const j = await res.json().catch(()=>({})); showToast(j?.errors?.[0]?.message || 'Formspree error. Falling back…', false); }
      }catch{ showToast('Network error with Formspree. Falling back…', false); }
    }
    if(!toast.textContent.includes('Thanks')){
      const subject = encodeURIComponent(`Job Application — ${data.name}`);
      const body = encodeURIComponent(`Role/Skills: ${data.skills}\nPhone: ${data.phone}\nEmail: ${data.email}\n\nMessage:\n${data.message||''}`);
      window.location.href = `mailto:${BRAND_EMAIL}?subject=${subject}&body=${body}`;
      showToast('Opening your email app to send the application…');
    }
    spinner?.classList?.add('hidden'); if(applyBtn) applyBtn.disabled = false;
  }, {passive:false});
})();

/* ===== Service Worker ===== */
if('serviceWorker' in navigator){
  window.addEventListener('load', ()=>{
    navigator.serviceWorker.register('/sw.js').catch(console.warn);
  });
}
